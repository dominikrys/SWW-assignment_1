# Software Workshop - Assignment 1 - Messaging System
### By Dominik Rys (dxr714)

SOLUTION.md provided in src folder